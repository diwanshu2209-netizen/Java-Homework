// Spy Number

public class SpyNumber {
    public static void main(String[] args) {
        int n = 1124;
        int sum = 0, product = 1;
        int temp = n;

        for(; temp != 0; temp /= 10) {
            int d = temp % 10;
            sum += d;
            product *= d;
        }

        if(sum == product)
            System.out.println("Spy Number");
        else
            System.out.println("Not Spy Number");
    }
}

// Output: Spy Number

/* Second Time
public class SpyNumber {
    public static void main(String[] args) {
        int n = 1124;
        int sum = 0, product = 1;
        int temp = n;

        for(; temp != 0; temp /= 10) {
            int d = temp % 10;
            sum += d;
            product *= d;
        }

        if(sum == product)
            System.out.println("Spy Number");
        else
            System.out.println("Not Spy Number");
    }
}
*/

/* Third Time
public class SpyNumber {
    public static void main(String[] args) {
        int n = 1124;
        int sum = 0, product = 1;
        int temp = n;

        for(; temp != 0; temp /= 10) {
            int d = temp % 10;
            sum += d;
            product *= d;
        }

        if(sum == product)
            System.out.println("Spy Number");
        else
            System.out.println("Not Spy Number");
    }
}
*/
