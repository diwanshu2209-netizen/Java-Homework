// PowerSeries: x + x² + x³ + ...

public class PowerSeries {
    public static void main(String[] args) {
        int x = 2, n = 5;
        int sum = 0;
        int term = 1;

        for(int i = 1; i <= n; i++) {
            term *= x;
            sum += term;
        }

        System.out.println("Sum: " + sum);
    }
}

// Output: Sum: 62

/* Second Time
public class PowerSeries {
    public static void main(String[] args) {
        int x = 2, n = 5;
        int sum = 0;
        int term = 1;

        for(int i = 1; i <= n; i++) {
            term *= x;
            sum += term;
        }

        System.out.println("Sum: " + sum);
    }
}
*/

/* Third Time
public class PowerSeries {
    public static void main(String[] args) {
        int x = 2, n = 5;
        int sum = 0;
        int term = 1;

        for(int i = 1; i <= n; i++) {
            term *= x;
            sum += term;
        }

        System.out.println("Sum: " + sum);
    }
}
*/
