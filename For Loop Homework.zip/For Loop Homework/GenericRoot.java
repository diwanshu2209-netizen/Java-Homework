// Generic Root

public class GenericRoot {
    public static void main(String[] args) {
        int n = 99;

        for(; n > 9;) {
            int sum = 0;
            int temp = n;

            for(; temp > 0; temp /= 10)
                sum += temp % 10;

            n = sum;
        }

        System.out.println("Generic Root: " + n);
    }
}

// Output: Generic Root: 9

/* Second Time
public class GenericRoot {
    public static void main(String[] args) {
        int n = 99;

        for(; n > 9;) {
            int sum = 0;
            int temp = n;

            for(; temp > 0; temp /= 10)
                sum += temp % 10;

            n = sum;
        }

        System.out.println("Generic Root: " + n);
    }
}
*/

/* Third Time
public class GenericRoot {
    public static void main(String[] args) {
        int n = 99;

        for(; n > 9;) {
            int sum = 0;
            int temp = n;

            for(; temp > 0; temp /= 10)
                sum += temp % 10;

            n = sum;
        }

        System.out.println("Generic Root: " + n);
    }
}
*/
