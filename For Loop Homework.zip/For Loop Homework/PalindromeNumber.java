// Palindrome Number

public class PalindromeNumber {
    public static void main(String[] args) {
        int n = 121;
        int temp = n;
        int rev = 0;

        for(; temp != 0; temp /= 10) {
            rev = rev * 10 + temp % 10;
        }

        if(n == rev)
            System.out.println("Palindrome");
        else
            System.out.println("Not Palindrome");
    }
}

// Output: Palindrome

/* Second Time
public class PalindromeNumber {
    public static void main(String[] args) {
        int n = 121;
        int temp = n;
        int rev = 0;

        for(; temp != 0; temp /= 10) {
            rev = rev * 10 + temp % 10;
        }

        if(n == rev)
            System.out.println("Palindrome");
        else
            System.out.println("Not Palindrome");
    }
}
*/

/* Third Time
public class PalindromeNumber {
    public static void main(String[] args) {
        int n = 121;
        int temp = n;
        int rev = 0;

        for(; temp != 0; temp /= 10) {
            rev = rev * 10 + temp % 10;
        }

        if(n == rev)
            System.out.println("Palindrome");
        else
            System.out.println("Not Palindrome");
    }
}
*/
