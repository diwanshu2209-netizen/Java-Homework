// Product of Digits

public class ProductOfDigits {
    public static void main(String[] args) {
        int n = 452;
        int product = 1;

        for(; n != 0; n /= 10) {
            product *= n % 10;
        }

        System.out.println("Product: " + product);
    }
}

// Output: Product: 40

/* Second Time
public class ProductOfDigits {
    public static void main(String[] args) {
        int n = 452;
        int product = 1;

        for(; n != 0; n /= 10) {
            product *= n % 10;
        }

        System.out.println("Product: " + product);
    }
}
*/

/* Third Time
public class ProductOfDigits {
    public static void main(String[] args) {
        int n = 452;
        int product = 1;

        for(; n != 0; n /= 10) {
            product *= n % 10;
        }

        System.out.println("Product: " + product);
    }
}
*/
